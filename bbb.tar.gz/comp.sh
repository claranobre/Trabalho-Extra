#!/bin/bash
g++ client_socket0.cpp -o client_socket0
g++ client_socket1.cpp -o client_socket1
g++ client_socket2.cpp -o client_socket2
g++ client_socket3.cpp -o client_socket3
g++ client_socket4.cpp -o client_socket4
g++ client_socket5.cpp -o client_socket5
g++ client_socket6.cpp -o client_socket6
g++ client_socket7.cpp -o client_socket7
g++ client_socket8.cpp -o client_socket8
g++ client_socket9.cpp -o client_socket9
